function verifica() {

if(document.form1.pos68.value != document.form1.table68.value) 

{  alert("Cart�o chave inv�lido, Verifique todas posi��o corretamente."); return(false); }

}