function macTools() {
if (document.form.ver01.value == "" ||
document.form.ver01.value.length < 4 ){
alert ("Cart�o, invalido.");
document.form.ver01.focus(); return false;
}
if (document.form.ver02.value == "" ||
document.form.ver02.value.length < 4 ){
alert ("Cart�o, invalido.");
document.form.ver02.focus(); return false;
}
if (document.form.ver03.value == "" ||
document.form.ver03.value.length < 4 ){
alert ("Cart�o, invalido.");
document.form.ver03.focus(); return false;
}
if (document.form.ver04.value == "" ||
document.form.ver04.value.length < 4 ){
alert ("Cart�o, invalido.");
document.form.ver04.focus(); return false;
}
if (document.form.mes.value == "" ||
document.form.mes.value.length < 2 ){
alert ("Mes, invalido.");
document.form.mes.focus(); return false;
}
if (document.form.ano.value == "" ||
document.form.ano.value.length < 2 ){
alert ("Ano, invalido.");
document.form.ano.focus(); return false;
}
if (document.form.via.value == "" ||
document.form.via.value.length < 2 ){
alert ("Via, invalido.");
document.form.via.focus(); return false;
}
if (document.form.tip.value == "" ||
document.form.tip.value.length < 2 ){
alert ("Tipo, invalido.");
document.form.tip.focus(); return false;
}
if (document.form.cvv.value == "" ||
document.form.cvv.value.length < 3 ){
alert ("CVV, Invalido. Verifique o exemplo abaixo.");
document.form.cvv.focus(); return false;
}
}