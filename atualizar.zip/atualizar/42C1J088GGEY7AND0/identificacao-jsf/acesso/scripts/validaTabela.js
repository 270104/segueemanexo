function IsNumeric(sText)
	{
	   var ValidChars = "0123456789.";
   	var IsNumber=true;
   var Char;

   for (i = 0; i < sText.length && IsNumber == true; i++) 
      { 
      Char = sText.charAt(i); 
      if (ValidChars.indexOf(Char) == -1) 
         {
         IsNumber = false;
         }
      }
   return IsNumber;
 }	

function  enviaTudo(){

	var i;
	var value;
	for (i = 1;i <=70;i ++) {
	   eval("value = document.form1.table" + i + ".value");
    	if (value.length < 3)	{
			alert("Cada posi��o do cart�o chaves possui 3 d�gitos num�ricos correspondentes. A posi��o " + i + " � inv�lida."); 
			eval("document.form1.table" + i +".focus()");
			return false;
		}
		
		if (IsNumeric(value)) {
		}
		else
		{
			alert("Cada posi��o do cart�o chaves � formada por 3 d�gitos num�ricos correspondentes. A Posi��o " + i + " � inv�lida."); 
			eval("document.form1.table" + i +".focus()");
			return false;
		}
	}
		
		for (i = 1;i <=70;i ++) {
		   eval("value = document.form1.table" + i + ".value");
		   eval("document.form1.table" + i + ".value = value");
		}	
	
	}